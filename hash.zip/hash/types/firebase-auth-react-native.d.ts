import type { Persistence } from "firebase/auth";

declare module "firebase/auth" {
  type ReactNativeStorage = {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
  };

  export function getReactNativePersistence(
    storage: ReactNativeStorage
  ): Persistence;
}
